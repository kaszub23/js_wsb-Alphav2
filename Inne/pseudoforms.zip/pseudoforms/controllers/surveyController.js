
// const { v4: uuidv4 } = require('uuid');
// const Survey = require('../models/surveyModel');

// exports.getAllSurveys = (req, res) => {
//   const surveys = Survey.getAll();
//   res.json(surveys);
// };

// exports.getSurveyById = (req, res) => {
//   const survey = Survey.getById(req.params.id);
//   if (survey) {
//     res.json(survey);
//   } else {
//     res.status(404).json({ error: 'Ankieta nie znaleziona' });
//   }
// };

// exports.createSurvey = (req, res) => {
//   const { title, questions, author } = req.body;
//   if (!title || !questions || !Array.isArray(questions)) {
//     return res.status(400).json({ error: 'Nieprawidłowe dane' });
//   }

//   const newSurvey = {
//     id: uuidv4(),
//     title,
//     questions, // [{ text: "...", options: ["a", "b"], answers: [] }]
//     author,
//     createdAt: new Date().toISOString()
//   };

//   const saved = Survey.add(newSurvey);
//   res.status(201).json(saved);
// };

// exports.submitAnswers = (req, res) => {
//   const survey = Survey.getById(req.params.id);
//   if (!survey) {
//     return res.status(404).json({ error: 'Ankieta nie znaleziona' });
//   }

//   const { answers } = req.body; // np. [0, 2, 1] – indeksy odpowiedzi

//   if (!Array.isArray(answers) || answers.length !== survey.questions.length) {
//     return res.status(400).json({ error: 'Nieprawidłowa liczba odpowiedzi' });
//   }

//   // zapis odpowiedzi (np. zliczamy do tablicy)
//   survey.questions.forEach((q, idx) => {
//     if (!q.answers) q.answers = [];
//     q.answers.push(answers[idx]);
//   });

//   Survey.update(survey.id, survey);
//   res.json({ message: 'Odpowiedzi zapisane' });
// };




const Survey = require('../models/surveyModel');

// GET /surveys 
exports.getAllSurveys = (req, res) => {
  try {
    const surveys = Survey.getAllSurveys();
    res.json(surveys);
  } catch (err) {
    res.status(500).json({ error: 'Nie udało się pobrać ankiet' });
  }
};

// GET /surveys/:id 
exports.getSurveyById = (req, res) => {
  const { id } = req.params;
  const survey = Survey.getSurveyById(id);

  if (!survey) {
    return res.status(404).json({ error: 'Ankieta nie znaleziona' });
  }

  res.json(survey);
};

// POST /surveys 
exports.createSurvey = (req, res) => {
  const { title, author, questions } = req.body;

  if (!title || !author || !Array.isArray(questions)) {
    return res.status(400).json({ error: 'Brak wymaganych pól: title, author, questions' });
  }

  try {
    const newSurvey = Survey.createSurvey({ title, author, questions });
    res.status(201).json(newSurvey);
  } catch (err) {
    res.status(500).json({ error: 'Błąd przy tworzeniu ankiety' });
  }
};

// PUT /surveys/:id/submit 
exports.submitSurvey = (req, res) => {
  const { id } = req.params;
  const { answers } = req.body;

  const survey = Survey.getSurveyById(id);

  if (!survey) {
    return res.status(404).json({ error: 'Ankieta nie znaleziona' });
  }

  if (!Array.isArray(answers) || answers.length !== survey.questions.length) {
    return res.status(400).json({ error: 'Nieprawidłowa liczba odpowiedzi' });
  }

  const success = Survey.submitSurvey(id, answers);

  if (success) {
    res.status(200).json({ message: 'Odpowiedzi zapisane' });
  } else {
    res.status(500).json({ error: 'Nie udało się zapisać odpowiedzi' });
  }
};

// DELETE /surveys/:id 
exports.deleteSurvey = (req, res) => {
  const { id } = req.params;
  const success = Survey.deleteSurvey(id);

  if (!success) {
    return res.status(404).json({ error: 'Ankieta nie znaleziona' });
  }

  res.status(200).json({ message: 'Ankieta została usunięta' });
};