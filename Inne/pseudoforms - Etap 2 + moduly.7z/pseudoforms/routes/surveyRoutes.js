const express = require('express');
const router = express.Router();
const surveyController = require('../controllers/surveyController');

router.get('/', surveyController.getAllSurveys);
router.get('/:id', surveyController.getSurveyById);
router.post('/', surveyController.createSurvey);
router.put('/:id/submit', surveyController.submitSurvey);
router.delete('/:id', surveyController.deleteSurvey);

module.exports = router;
