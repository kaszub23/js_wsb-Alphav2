const surveyModel = require(`../models/surveyModel`);

exports.getAllSurveys = () => {
  return surveyModel.getAllSurveys();
};
exports.getSurveyById = (id) => {
  return surveyModel.getSurveyById(id);
};
exports.createSurveys = ({ title, author, questions }) => {
  return surveyModel.createSurvey({ title, author, questions });
};
exports.submitSurvey = (id, question_id, respondent_id, response_text_json) => {
  return surveyModel.submitSurvey(id, question_id, respondent_id, response_text_json);
};
exports.deleteSurvey = (id) => {
  return surveyModel.deleteSurvey(id);
};