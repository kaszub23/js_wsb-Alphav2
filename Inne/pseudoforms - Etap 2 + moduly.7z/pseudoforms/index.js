const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;
const surveyRoutes = require('./routes/surveyRoutes');
const path = require('path');

app.use(express.json());

app.use('/surveys', surveyRoutes);

//Błędy
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Coś poszło nie tak!' });
});

app.listen(PORT, () => {
  console.log(`Serwer działa na http://localhost:${PORT}`);
});