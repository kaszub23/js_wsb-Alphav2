const API_URL = 'http://localhost:3000/surveys';

document.addEventListener('DOMContentLoaded', () => {
  loadSurveys();

  document.getElementById('surveyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = e.target.title.value;
    const question1 = e.target.question1.value;
    const question2 = e.target.question2.value;

    const questions = [
      { text: question1, question_type: "text", options: [] }
    ];
    if (question2) {
      questions.push({ text: question2, question_type: "text", options: [] });
    }

    await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, author: null, questions })
    });

    e.target.reset();
    loadSurveys();
  });
});

async function loadSurveys() {
  const res = await fetch(API_URL);
  const surveys = await res.json();

  const list = document.getElementById('surveyList');
  list.innerHTML = '';

  surveys.forEach(survey => {
    const li = document.createElement('li');

    const titleSpan = document.createElement('span');
    titleSpan.textContent = survey.title;
    titleSpan.classList.add('survey-item');
    titleSpan.onclick = () => loadSurveyDetails(survey.id);

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Usuń';
    deleteBtn.style.marginLeft = '1em';
    deleteBtn.onclick = async (e) => {
      e.stopPropagation();
      if (confirm(`Czy na pewno chcesz usunąć ankietę "${survey.title}"?`)) {
        await fetch(`${API_URL}/${survey.id}`, { method: 'DELETE' });
        document.getElementById('surveyDetails').innerHTML = '';
        loadSurveys();
      }
    };

    li.appendChild(titleSpan);
    li.appendChild(deleteBtn);
    list.appendChild(li);
  });
}


async function loadSurveyDetails(id) {
  const res = await fetch(`${API_URL}/${id}`);
  if (!res.ok) return;

  const survey = await res.json();
  const details = document.getElementById('surveyDetails');
  details.innerHTML = `
    <h3>Szczegóły ankiety: ${survey.title}</h3>
    <p>ID: ${survey.id}</p>
    <p>Autor: ${survey.author_id || 'anonimowy'}</p>
    <p>Utworzono: ${new Date(survey.created_at).toLocaleString()}</p>
    <h4>Pytania:</h4>
    <ul>
      ${survey.questions.map(q => `<li class="question">${q.text} (${q.type})</li>`).join('')}
    </ul>
  `;
}
